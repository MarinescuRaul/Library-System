#include "Revista.h"

Revista::Revista()
{
    //ctor
}

Revista::~Revista()
{
    //dtor
}
